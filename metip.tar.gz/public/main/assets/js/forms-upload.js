$(document).ready(function() {

   $('.dropify').dropify();
   
});