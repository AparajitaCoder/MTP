@extends ('user.layout.app')
@section('content')
<section class="content">
	<div class="full-width">
		<img src="{{asset('/asset/images/about-img.jpg')}}" alt="" class="imgleft">
		<h1>About Us</h1>
		<p>Contrary to popular belief, Lorem Ipsum is not simply random text.
			It has roots in a piece of classical Latin literature from 45 BC,
			making it over 2000 years old. Richard McClintock, a Latin professor
			at Hampden-Sydney College in Virginia, looked up one of the more
			obscure Latin words, consectetur, from a Lorem Ipsum passage, and
			going through the cites of the word in classical literature,
			discovered the undoubtable source. Lorem Ipsum comes from sections
			1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes
			of Good and Evil) by Cicero, written in 45 BC. Latin literature from
			45 BC, making it over 2000 years old. Richard McClintock, a Latin
			professor at Hampden-Sydney College in Virginia, l</p>
		<p>Looked up one of the more obscure Latin words, consectetur, from a
			Lorem Ipsum passage, and going through the cites of the word in
			classical literature, discovered the undoubtable source. Lorem Ipsum
			comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et
			Malorum" (The Extremes of Good and Evil)</p>
		<p>Contrary to popular belief, Lorem Ipsum is not simply random text.
			It has roots in a piece of classical Latin literature from 45 BC,
			making it over 2000 years old. Richard McClintock, a Latin professor
			at Hampden-Sydney College in Virginia, looked up one of the more
			obscure Latin words, consectetur, from a Lorem Ipsum passage, and
			going through the cites of the word in classical literature,
			discovered the undoubtable source. Lorem Ipsum comes from sections
			1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes
			of Good and Evil) by Cicero, written in 45 BC.</p>
		<h4>Condimentum diam lacinia justo dolor</h4>
		<ul>
			<li>Malesuada metus tempus Cras cursus</li>
			<li>Hampden-Sydney College in Virginia, looked up</li>
			<li>Looked up one of the more obscure Latin</li>
			<li>Discovered the undoubtable source. Lorem Ipsum</li>
			<li>Virginia looked up one of the more obscure</li>
		</ul>
		<div class="post-grids">
			<div class="row">
				<div class="col-md-4">
					<div class="post-img">
						<img src="{{asset('/asset/images/post-img1.jpg')}}" alt="">
					</div>
					<h4>We Are Best Team</h4>
					<h3>Make Business Strategy</h3>
					<p>Contrary to popular belief, Lorem Ipsum is not simply random
						text. It has roots in a piece of classical Latin literature from</p>
				</div>
				<div class="col-md-4">
					<div class="post-img">
						<img src="{{asset('/asset/images/post-img2.jpg')}}" alt="">
					</div>
					<h4>The Best Company</h4>
					<h3>Company of Professionals</h3>
					<p>Contrary to popular belief, Lorem Ipsum is not simply random
						text. It has roots in a piece of classical Latin literature from</p>
				</div>
				<div class="col-md-4">
					<div class="post-img">
						<img src="{{asset('/asset/images/post-img3.jpg')}}" alt="">
					</div>
					<h4>Always Forvard</h4>
					<h3>We Love Our Clients</h3>
					<p>Contrary to popular belief, Lorem Ipsum is not simply random
						text. It has roots in a piece of classical Latin literature from</p>
				</div>
			</div>
		</div>
	</div>
</section>
@endsection