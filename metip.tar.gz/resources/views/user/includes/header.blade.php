<header>
	<div class="top-header">
  		<div class="col-md-3 logo">
  			<img src="{{ asset('/asset/logo.png') }}" alt="METIP" />
  		</div>
  		<div class="pull-right login-right">
  			<button type="button" class="btn btn-default" data-toggle="modal" data-target="#loginPopup">Login</button>
  			<button type="button" class="btn btn-default yellow" data-toggle="modal" data-target="#registerPopup">Register</button>
  		</div>
  	</div>  	
	<nav class="nav">
		<ul class="navigation">
			<li class="{{ (Request::path() == '/') ? 'active' : '' }}"><a href="{{ url('/') }}">Home</a></li>
			<li class="{{ (Request::path() == 'about-us') ? 'active' : '' }}"><a href="{{ url('/about-us') }}">About us</a></li>
			<li class="{{ (Request::path() == 'innovation') ? 'active' : '' }}"><a href="{{ url('/innovation') }}">Innovation</a></li>
			<li class="{{ (Request::path() == 'marketing') ? 'active' : '' }}"><a href="#">Marketing</a></li>
			<li class="{{ (Request::path() == 'support') ? 'active' : '' }}"><a href="{{ url('/support') }}">Support</a></li>
			<li class="{{ (Request::path() == 'mlt') ? 'active' : '' }}"><a href="#">MLT</a></li>
			<li class="{{ (Request::path() == 'contact') ? 'active' : '' }}"><a href="{{ url('/contact') }}">Contact</a></li>
		</ul>
	</nav>
</header>