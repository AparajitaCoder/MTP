<div class="modal fade" id="registerPopup" tabindex="-1" role="dialog" aria-labelledby="registerPopupLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="registerPopupLabel">Register</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="reg-profile-pic">
          <div class="rpp"><img src="{{ asset('/asset/images/profile-default.jpg') }}" alt=""></div>
          <label class="upload-picture">
            <input type="file">
            Upload Picture
          </label>
        </div>
        <div class="input-row">
          <input type="text" placeholder="First Name">
        </div>
        <div class="input-row">
          <input type="text" placeholder="Last Name">
        </div>
        <div class="input-row">
          <input type="email" placeholder="E-mail">
        </div>
        <div class="input-row">
          <input type="password" placeholder="Password">
        </div>
        <div class="input-row">
          <input type="password" placeholder="Confirm Password">
        </div>
        <div class="input-row">
          <div class="i-agree">
            <input type="checkbox"> I agree with <a href="#">Terms &amp; Conditions</a>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary yellow">Registration</button>
      </div>
    </div>
  </div>
</div>