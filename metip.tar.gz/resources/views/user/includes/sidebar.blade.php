<div class="sidebar col-md-3">
	<h4 class="list-heading">Main Menu</h4>
	<ul class="side-menu">
			<li> <a href="#">Dummy link1</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Dummy link2</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Dummy link3</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Dummy link4</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Dummy link5</a> <i class="fa fa-angle-right"></i></li>
		</ul>
		
		<h4 class="list-heading">Resources</h4>
		<ul class="side-menu">
			<li> <a href="#">Forums</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Performance</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Help</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">FAQ</a> <i class="fa fa-angle-right"></i></li>
			<li> <a href="#">Arial</a> <i class="fa fa-angle-right"></i></li>
		</ul>
		
		<h4 class="list-heading">Our Staff</h4>
		<div class="x_content">
    <ul class="list-unstyled msg_list">
      <li>
        <a>
          <span class="image">
            <img src="{{ asset('/asset/images/img1.jpg') }}" alt="img">
          </span>
          <div class="name"><span>Charles Nicholes</span></div>
          <span class="message">Ceo &amp; Managing Director</span>
        </a>
      </li>
      <li>
        <a>
          <span class="image">
            <img src="{{ asset('/asset/images/img2.jpg') }}" alt="img">
          </span>
          <div class="name"><span>Rebecca Garza</span></div>
          <span class="message">Business Developer</span>
        </a>
      </li>
      <li>
        <a>
          <span class="image">
            <img src="{{ asset('/asset/images/img3.jpg') }}" alt="img">
          </span>
          <div class="name"><span>Stepthen Adams</span></div>
          <span class="message">Finance Officer</span>
        </a>
      </li>
      <li>
        <a>
          <span class="image">
            <img src="{{ asset('/asset/images/img4.jpg') }}" alt="img">
          </span>
          <div class="name"><span>Ben Johnson</span></div>
          <span class="message">Marketing Officer</span>
        </a>
      </li>
    </ul>
  </div>
</div>  