<header>
	<div class="top-header">
  		<div class="col-md-3 logo">
  			<img src="<?php echo e(asset('/asset/logo.png')); ?>" alt="METIP" />
  		</div>
  		<div class="pull-right login-right">
  			<button type="button" class="btn btn-default" data-toggle="modal" data-target="#loginPopup">Login</button>
  			<button type="button" class="btn btn-default yellow" data-toggle="modal" data-target="#registerPopup">Register</button>
  		</div>
  	</div>  	
	<nav class="nav">
		<ul class="navigation">
			<li class="<?php echo e((Request::path() == '/') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li class="<?php echo e((Request::path() == 'about-us') ? 'active' : ''); ?>"><a href="<?php echo e(url('/about-us')); ?>">About us</a></li>
			<li class="<?php echo e((Request::path() == 'innovation') ? 'active' : ''); ?>"><a href="<?php echo e(url('/innovation')); ?>">Innovation</a></li>
			<li class="<?php echo e((Request::path() == 'marketing') ? 'active' : ''); ?>"><a href="#">Marketing</a></li>
			<li class="<?php echo e((Request::path() == 'support') ? 'active' : ''); ?>"><a href="<?php echo e(url('/support')); ?>">Support</a></li>
			<li class="<?php echo e((Request::path() == 'mlt') ? 'active' : ''); ?>"><a href="#">MLT</a></li>
			<li class="<?php echo e((Request::path() == 'contact') ? 'active' : ''); ?>"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
		</ul>
	</nav>
</header>