<?php $__env->startSection('content'); ?>
<section class="content">
<div class="support-header">
  <h1>How can we help you?</h1>
  <input type="text" placeholder="Search">
</div>
<div class="support-list">
      <a href="#">
        <label>Getting Started Guides</label>
        Check out all of our "Getting Started Guides" to help you work better with metip
      </a>
      <a href="#">
        <label>General Documentation</label>
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
      </a>
      <a href="#">
        <label>FAQ</label>
        Frequently asked questions about Lingotek and our products
      </a>
      <a href="#">
        <label>Lorem Ipsum</label>
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
      </a>
      <a href="#">
        <label>Contrary to popular</label>
        Contrary to popular belief, Lorem Ipsum is not simply random text.
      </a>
      <a href="#">
        <label>Where can I get some</label>
        There are many variations of passages of Lorem Ipsum available, but the majority have
      </a>
      <a href="#">
        <label>Lorem Ipsum</label>
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
      </a>
      <a href="#">
        <label>Contrary to popular</label>
        Contrary to popular belief, Lorem Ipsum is not simply random text.
      </a>
      <a href="#">
        <label>Where can I get some</label>
        There are many variations of passages of Lorem Ipsum available, but the majority have
      </a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>