  <footer>
    <div class="footer-top">
      <div class="footer-col1">
        <img src="<?php echo e(asset('/asset/logo.png')); ?>" alt="METIP" />
        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum </p>
      </div>
      <div class="footer-col2">
        <h3>Usefull links</h3>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about-us.html">About us</a></li>
          <li><a href="innovation.html">Innovation</a></li>
          <li><a href="#">Marketing</a></li>
          <li><a href="support.html">Support</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
      </div>
      <div class="footer-col3">
        <h3>Contact Us</h3>
        <p>22/121 Apple Street, New York, NY 10012, USA</p>
        <p>Phone: +123-456-7890<br>
          Mail@mteip.com</p>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-google-plus-g"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
    <div class="copyright">
      Copyright &copy; 2018 METIP Site. All Rights Reserved.
    </div>
  </footer>