<?php $__env->startSection('content'); ?>
<section class="content">
	<?php echo $__env->make('user.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
	
	<div class="right-side col-md-9">
  <div id="mainslider" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#mainslider" data-slide-to="0" class="active"></li>
      <li data-target="#mainslider" data-slide-to="1"></li>
      <li data-target="#mainslider" data-slide-to="2"></li>
      <li data-target="#mainslider" data-slide-to="3"></li>
    </ol>
    <div class="carousel-inner">
      <div class="item active">
        <img src="<?php echo e(asset('/asset/images/slide1.jpg')); ?>" alt="" />
        <div class="carousel-caption">
          <h2>We works with focus <span>innovate</span> and grow. </h2>
          <p>With over 10 years of experience helping businesses to find </p>
        </div>
      </div>
      <div class="item">
        <img src="<?php echo e(asset('/asset/images/slide1.jpg')); ?>" alt="" />
        <div class="carousel-caption">
          <h2>We works with focus <span>innovate</span> and grow. </h2>
          <p>With over 10 years of experience helping businesses to find </p>
        </div>
      </div>
      <div class="item">
        <img src="<?php echo e(asset('/asset/images/slide1.jpg')); ?>" alt="" />
        <div class="carousel-caption">
          <h2>We works with focus <span>innovate</span> and grow. </h2>
          <p>With over 10 years of experience helping businesses to find </p>
        </div>
      </div>
      <div class="item">
        <img src="<?php echo e(asset('/asset/images/slide1.jpg')); ?>" alt="" />
        <div class="carousel-caption">
          <h2>We works with focus <span>innovate</span> and grow. </h2>
          <p>With over 10 years of experience helping businesses to find </p>
        </div>
      </div>
    </div>
  </div>
		<div class="content-area clearfix">
    <div class="post-list">
			<div class="content-box">
				<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. lorem Ipsum has </h3>
				<span class="publish-date"> Published: 01 Jan 2018 </span>
				<figure class="col-md-4 left-img">
					<img src="<?php echo e(asset('/asset/images/content-img1.jpg')); ?>" alt="" />
				</figure>
				<div class="col-md-8">
					<p> Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. </p>
					<a class="btn btn-default yellow-btn"> Read More </a>
				</div>
			  </div>
			<div class="content-box">
				<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. lorem Ipsum has </h3>
				<span class="publish-date"> Published: 01 Jan 2018 </span>
				<figure class="col-md-4 left-img">
					<img src="<?php echo e(asset('/asset/images/content-img1.jpg')); ?>" alt="" />
				</figure>
				<div class="col-md-8">
					<p> Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. </p>
					<a class="btn btn-default yellow-btn"> Read More </a>
				</div>
			  </div>
			<div class="content-box">
				<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. lorem Ipsum has </h3>
				<span class="publish-date"> Published: 01 Jan 2018 </span>
				<figure class="col-md-4 left-img">
					<img src="<?php echo e(asset('/asset/images/content-img1.jpg')); ?>" alt="" />
				</figure>
				<div class="col-md-8">
					<p> Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. </p>
					<a class="btn btn-default yellow-btn"> Read More </a>
				</div>
			  </div>
    </div>
			<div class="pagination">
				<ul>
					<li class="active"> <a href="#_"> 1 </a> </li>
					<li> <a href="#_"> 2 </a> </li>
					<li> <a href="#_"> 3 </a> </li>
					<li> <a href="#_"> 4 </a> </li>
					<li class="next"> <a href="#_"> >> </a> </li>
				</ul>
			</div>
		</div>
	</div> 		
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>