/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'sq', {
	copy: 'Të drejtat  e kopjimit &copy; $1. Të gjitha të drejtat e rezervuara.',
	dlgTitle: 'Rreth CKEditor 4',
	moreInfo: 'Për informacione rreth licencave shih faqen tonë:'
} );
